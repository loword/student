package com.meishe.sdkdemo.edit.data;

/**
 * Created by admin on 2018/7/10.
 */

public class CaptionColorInfo {
    public String mColorValue;
    public boolean mSelected;
    public CaptionColorInfo(String colorValue,boolean isSelected){
        mColorValue = colorValue;
        mSelected = isSelected;
    }
}