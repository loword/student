package com.meishe.sdkdemo.main;

import android.view.View;

/**
 * Created by CaoZhiChao on 2018/11/12 17:36
 */
public interface OnItemClickListener {
    void onClick(View view);
}
