package com.meishe.sdkdemo.capturescene.httputils.download;

/**
 * Created by CaoZhiChao on 2018/12/1 17:14
 */
public class DownloadInfo {
    public static final long TOTAL_ERROR = -1;//获取进度失败

}
