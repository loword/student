package com.meishe.sdkdemo.utils;

/**
 * Created by yyj on 2018/1/22 0022.
 */

public class StickerAssets {
    private String path;
    private String picture;

    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path;
    }

    public String getPicture() {
        return picture;
    }
    public void setPicture(String picture) {
        this.picture = picture;
    }
}
