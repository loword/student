package com.meishe.sdkdemo.base;

/**
 * Created by CaoZhiChao on 2018/5/31 10:55
 * 数据类
 */
public class BaseConstants {
    public static final boolean ISDEBUG=true;
    public static final float EDITGRALLYSCALE=0.82f;
    public static final String CAPTURESCENE_DIALOG_SP_KEY="captureScene_sp_key";
}
