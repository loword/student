package com.meishe.sdkdemo.capturescene.httputils;

/**
 * Created by CaoZhiChao on 2018/12/1 14:27
 */

public class Param {
    String key;
    String value;

    public Param() {
    }

    public Param(String key, String value) {
        this.key = key;
        this.value = value;
    }
}