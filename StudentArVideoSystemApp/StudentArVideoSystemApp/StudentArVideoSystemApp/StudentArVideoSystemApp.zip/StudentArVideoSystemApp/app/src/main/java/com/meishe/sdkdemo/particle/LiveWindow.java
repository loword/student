package com.meishe.sdkdemo.particle;

import android.content.Context;
import android.util.AttributeSet;

import com.meicam.sdk.NvsLiveWindow;

public class LiveWindow extends NvsLiveWindow {
    public LiveWindow(Context context) {
        super(context);
    }

    public LiveWindow(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }
}
