package com.meishe.sdkdemo.douyin.bean;



public class TimelineFxResourceObj {
    public int image;
    public String imageName;
    public int color;

    public boolean isShowWaitProgressBar;
    public boolean isSelected;

    public TimelineFxResourceObj(){
        isShowWaitProgressBar = false;
        isSelected = false;
    }
}
