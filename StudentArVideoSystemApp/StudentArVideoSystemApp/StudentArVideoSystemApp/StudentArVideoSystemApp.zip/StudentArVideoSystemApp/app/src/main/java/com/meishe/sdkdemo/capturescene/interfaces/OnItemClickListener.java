package com.meishe.sdkdemo.capturescene.interfaces;

import android.view.View;

/**
 * Created by CaoZhiChao on 2019/1/4 16:31
 */
public interface OnItemClickListener {
    void onClick(View view,int position);
}
