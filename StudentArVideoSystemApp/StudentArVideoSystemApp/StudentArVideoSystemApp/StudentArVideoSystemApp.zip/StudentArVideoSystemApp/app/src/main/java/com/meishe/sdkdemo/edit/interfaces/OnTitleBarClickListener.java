package com.meishe.sdkdemo.edit.interfaces;

/**
 * Created by CaoZhiChao on 2018/5/28 16:19
 */
public interface OnTitleBarClickListener {
    void OnBackImageClick();

    void OnCenterTextClick();

    void OnRightTextClick();
}
